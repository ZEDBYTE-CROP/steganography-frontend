export const environment = {
  production: true,
  baseUrl: 'http://3.110.87.140:5000'
};
